
#ifndef NTL_version__H
#define NTL_version__H

#define NTL_VERSION "9.7.1"

#define NTL_MAJOR_VERSION  (9)
#define NTL_MINOR_VERSION  (7)
#define NTL_REVISION       (1)

#endif

