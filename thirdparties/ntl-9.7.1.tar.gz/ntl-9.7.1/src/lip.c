
#include <NTL/config.h>

#ifdef NTL_GMP_LIP

#include "g_lip_impl.h"

#else

#include "c_lip_impl.h"

#endif
